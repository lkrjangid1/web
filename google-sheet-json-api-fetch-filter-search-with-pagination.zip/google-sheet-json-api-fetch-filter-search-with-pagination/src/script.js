// Enter your spredsheet ID
var spreadsheetID = "1se-enwg34Qaq8WJ27mooTTe2xalBxhd3W5AJnCnReeo";

jQuery(function($){
  
  // filter menu toggle
	$('.filter').click(function(event){
        event.stopPropagation();
        if($('.filter-menu').css('left')=='0px'){
			$('.filter-menu').animate({left: '-70%'}, 200);        
		}else{
			$('.filter-menu').animate({left:0}, 200); 
		}
    });
	
	$(".filter-menu").on("click", function (event) {
        event.stopPropagation();
    });
	
  // apply filter [change the spread sheet field name and filter text with yours]
	$('.apply-filter').click(function() {
		$('.filter-menu').animate({left: '-70%'}, 200);
		var filterchoosen = $("#rc_filter option:selected").text();		
		if(filterchoosen=='Language'){
			searchFieldData('language');
		} else if(filterchoosen=='Author'){
			searchFieldData('authorname');
		} else if(filterchoosen=='First ASC Number'){
			searchFieldData('firstascnum');
		} else if(filterchoosen=='Location'){
			searchFieldData('location');
		} else if(filterchoosen=='Call Number'){
			searchFieldData('callnum');
		} else {
			searchFieldData('select');
			$('.no-filter').show().fadeOut(1000);
		}
	});
	
  // search function [replace the spreadsheet field name with yours and also chagne the filter placeholder text upon applying filter]
	function searchFieldData(fltype){
		$.getJSON("https://spreadsheets.google.com/feeds/list/" + spreadsheetID + "/od6/public/values?alt=json", function(data) {
			var availableTags = [];
			
			$.each(data.feed.entry, function(k, v) {
				if(fltype=='authorname') {
					$('#bookname_enter').attr('placeholder','Enter Author Name');
					availableTags.push(v.gsx$authorname.$t);
				} else if (fltype=='language') {
					$('#bookname_enter').attr('placeholder','Enter Language');
					availableTags.push(v.gsx$language.$t);
				} else if (fltype=='firstascnum') {
					$('#bookname_enter').attr('placeholder','Enter First ASC');
					availableTags.push(v.gsx$firstascnum.$t);
				} else if (fltype=='location') {
					$('#bookname_enter').attr('placeholder','Enter Book Location');
					availableTags.push(v.gsx$location.$t);
				} else if (fltype=='callnum') {
					$('#bookname_enter').attr('placeholder','Enter Call Number');
					availableTags.push(v.gsx$callnum.$t);
				} else {
					$('#bookname_enter').attr('placeholder','Enter Book Name');
					availableTags.push(v.gsx$booktitle.$t);
				}
			});
			
      // jquery ui live search
			$("#bookname_enter").autocomplete({
				  source: function (request, response) {
					var matches = $.map(availableTags, function (acItem) {
						if (acItem.toUpperCase().indexOf(request.term.toUpperCase()) === 0) {
							return acItem;
						}
					});
					response(matches);
				}
			});
			
		});
	}
	
	// fetching data from goole sheet with pagination
	function bookList(booknm) {		
		var url = 'https://spreadsheets.google.com/feeds/list/' + spreadsheetID + '/od6/public/values?'+booknm+'alt\u003djson';
		//console.log(url);
		
		var perPage = 8;
		var currentPage = 1;
		var values = [];
		
		$(".loading").show();
		$.getJSON(url, function(data){
			if(!data.feed.entry || data.feed.entry.length === 0){
        // loading gif
				$(".loading").hide();
        
        // main data container
				$(".book-list").html('<li class="alert alert-danger">No books found</li>');
			} else {
        // data array from sheet
				var output = "";
				$.each(data.feed.entry, function(index, value) {
					values.push({
						Record: value.gsx$recordid.$t, 
						Title: value.gsx$booktitle.$t, 
						Author: value.gsx$authorname.$t, 
						FirstASC: value.gsx$firstascnum.$t, 
						Language: value.gsx$language.$t, 
						Location: value.gsx$location.$t, 
						Callnum: value.gsx$callnum.$t, 
						Isbnnum: value.gsx$isbnnum.$t, 
						Picture: value.gsx$picture.$t, 
						Description: value.gsx$decription.$t
					});
					if (index < perPage) {
						output +='<li class="list-item"><div class="media"><div class="media-left"><img src="'+value.gsx$picture.$t+'" class="media-object" style="width:85px"></div><div class="media-body"><h4 class="media-heading">'+value.gsx$booktitle.$t+'</h4><div><ul class="list-unstyled"><li><strong>Record ID:</strong><span>'+value.gsx$recordid.$t+'</span></li><li><strong>Author:</strong><span>'+value.gsx$authorname.$t+'</span></li><li><strong>First ACS Number:</strong><span>'+value.gsx$firstascnum.$t+'</span></li><li><strong>Language:</strong><span>'+value.gsx$language.$t+'</span></li><li><strong>Location:</strong><span>'+value.gsx$location.$t+'</span></li><li><strong>Call No.:</strong><span>'+value.gsx$callnum.$t+'</span></li><li><strong>ISBN:</strong><span>'+value.gsx$isbnnum.$t+'</span></li><li><strong>Description:</strong><span>'+value.gsx$decription.$t+'</span></li></ul><span class="sm">Details</span><span class="sl">Hide Details</span></div></div></div></li>';
					}
				});
				$(".loading").hide();
				$(".book-list").html(output);
			}
		}).fail(function () {
			$(".loading").hide();
			$(".book-list").html('<li class="alert alert-danger">No books found</li>');
		});
		
    // on paginate
		function changePage() {
			$(".book-list").html("");
			var start = (currentPage - 1) * perPage;
			var output = values.slice(start, start + perPage).reduce((s, e) => {
				return s += '<li class="list-item"><div class="media"><div class="media-left"><img src="'+e.Picture+'" class="media-object" style="width:85px"></div><div class="media-body"><h4 class="media-heading">'+e.Title+'</h4><div><ul class="list-unstyled"><li><strong>Record ID:</strong><span>'+e.Record+'</span></li><li><strong>Author:</strong><span>'+e.Author+'</span></li><li><strong>First ACS Number:</strong><span>'+e.FirstASC+'</span></li><li><strong>Language:</strong><span>'+e.Language+'</span></li><li><strong>Location:</strong><span>'+e.Location+'</span></li><li><strong>Call No.:</strong><span>'+e.Callnum+'</span></li><li><strong>ISBN:</strong><span>'+e.Isbnnum+'</span></li><li><strong>Description:</strong><span>'+e.Description+'</span></li></ul><span class="sm">Details</span><span class="sl">Hide Details</span></div></div></div></li>';    
			}, "");
			$(".book-list").html(output);
		}
		
		function numPages() {
			return Math.ceil(values.length / perPage);
		}
		
		$("#btn_prev").click(function() {
			if (currentPage > 1) {
				currentPage--;
				changePage();
			}
		});
		
		$("#btn_next").click(function() {
			if (currentPage < numPages()) {
				currentPage++;
				changePage();
			}
		});
	}
	
  // when search performend
	function mainSearch() {
		var booktitle = $('#bookname_enter').val();
		var filtervalue = $("#rc_filter option:selected").text();
		if(filtervalue=='Language'){
			var paravalue = 'language';
		} else if(filtervalue=='Author'){
			var paravalue = 'authorname';
		} else if(filtervalue=='First ASC Number'){
			var paravalue = 'firstascnum';
		} else if(filtervalue=='Location'){
			var paravalue = 'location';
		} else if(filtervalue=='Call Number'){
			var paravalue = 'callnum';
		} else {
			var paravalue = 'booktitle';
		}
		if(booktitle){
			var quot = decodeURI("%22");
			var upbooktitle = 'sq='+paravalue+'='+quot+booktitle+quot+'&';
			bookList(upbooktitle);
		} else {
			swal("Error", "Please enter to search!", "error");
		}
	}
	
	$(window).load(function() {
		searchFieldData();
		bookList('');
		$('.custom-pagination').show();	
	});
	
	$(document).on("click", ".ui-menu-item", function () {
		mainSearch();
		$('.clearable').show();
	});
	
	$('.clearable').click(function(){
		$(this).hide();
		searchFieldData();
		bookList('');
		$("#rc_filter option:selected").text('Select');
		$('#bookname_enter').val('');
	});	
	
});

$(document).on("click", function () {
	$('.filter-menu').animate({left: '-70%'}, 200);	
});

$(document).on('click', '.book-list .list-item .media .media-body .sm', function(){
	$(this).hide();
	$(this).parent().find('.list-unstyled').css('max-height', '999px');
	$(this).parent().find('.sl').show();
});

$(document).on('click', '.book-list .list-item .media .media-body .sl', function(){
	$(this).hide();
	$(this).parent().find('.list-unstyled').css('max-height', '71px');
	$(this).parent().find('.sm').show();
});