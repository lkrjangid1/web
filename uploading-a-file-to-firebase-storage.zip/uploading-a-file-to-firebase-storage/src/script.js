/********************
  See MSTU5013-CLASSWORK Database and Storage
  https://console.firebase.google.com/u/0/project/mstu5013-classwork/database/firestore/data~2Fphotos
  https://console.firebase.google.com/u/0/project/mstu5013-classwork/storage/mstu5013-classwork.appspot.com/files
********************/

// DATABASE REFERENCES
let db = firebase.firestore();
let photosRef = db.collection('photos');

// STORAGE REFERENCES
let storage = firebase.storage();
let storageRef = storage.ref(); // e.g. /
let photoFilesRef = storageRef.child('photos'); // e.g. /photos

// E.g. storageRef.child('a').child('b').child('c.jpg');  --- /a/b/c.jpg

Vue.component('photo-card', {
  props: ["photo"],
  template: "#photo"
});

let app = new Vue({
  el: "#app",
  data: {
    newFile: null,
    caption: "",
    photos: []
  },
  methods: {
    setFile(event) {
      this.newFile = event.target.files[0];
    },
    savePhoto() {
      let fileName = this.newFile.name;
      
      let metadata = {
        contentType: this.newFile.type
      };
      
      // NOTE: If you get a duplicate fileName, it'll overwrite the reference.
      // You can avoid this by making up a fileName like userID-timestamp-filename
      // Or whatever else would be a fairly unique fileName.
      
      // e.g. /photos/fileName
      let uploadTask = photoFilesRef.child(fileName).put(this.newFile, metadata);
      
      // Listen for upload state change: e.g. paused, running etc.
      uploadTask.on("state_changed", snapshot => {
        console.log(snapshot.state);
      
      // Callback if error
      }, error => {
        console.log("error uploading");
        
      // Callback if success
      }, () => {
        console.log("upload success");
        
        uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
          
          // Now that we have a downloadURL (file is on storage)
          // We can create the document with this URL info
          photosRef.add({
            caption: this.caption,
            url: downloadURL,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
          });
        });
        
      });
    }
  },
  mounted() {
    photosRef.orderBy('createdAt', 'desc').onSnapshot(querySnap => {
      this.photos = querySnap.docs.map(doc => doc.data());
    })
  }
});
