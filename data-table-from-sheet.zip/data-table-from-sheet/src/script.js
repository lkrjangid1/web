/* Google Sheet ID */
let sheetID = '1sKrv18XldcFasTzG2JQ-z4HBF8HwpX8xJWZ8xY_bWbM';

/* Function to fetch data from the Sheet */
function googleSheetURL(tabNumber = 1) {
  return 'https://spreadsheets.google.com/feeds/list/' + sheetID + '/' + tabNumber + '/public/values?alt=json';
}

let i;
let table = '';
let itemPluralName = 'Events'; // Plural name of items
let tableOrFinder = 'table'; // 'table' or 'finder'
let headers = ['When', 'Event', 'Library']
let columns = ['gsx$startdate', 'gsx$eventtitle', 'gsx$library']

async function fetchData() {
  const response = await fetch(googleSheetURL(2)),
        data = await response.json();
  return data;
}

async function displayTable(id='itemTable') {
  // Only progress if the numbers of headers and columns match
  if( tableOrFinder == 'table' && headers.length !== columns.length ) {
    console.log('The numbers of headers and columns must match');
    console.log('Headers', headers.length);
    console.log('Columns', columns.length);
    return false;
  }
  try {
    let data = await fetchData();
    let rows = data.feed.entry;

    // Build the table HTML
    table += '<table class="table table-striped">';
    table += '<thead><tr>';
    if( tableOrFinder == 'finder' ) {
      table += '<th>' + itemPluralName + '</th>';
    } else {
      headers.forEach((header) => {
        table += '<th>' + header + '</th>';
      })
    }
    table += '</tr></thead>';
    table += '<tbody>';
    rows.forEach((row) => {
      table += '<tr>';
      if( tableOrFinder == 'finder' ) {
        table += '<td>';
        table += '<h2>' + row['gsx$eventtitle']['$t'] + '</h2>';
        table += '<p><strong>Date</strong>: ' + row['gsx$startdate']['$t'] + '</p>';
        table += '<p><strong>Library</strong>: <a target="_blank" href="https://maps.google.com?q=' + row['gsx$location']['$t'] + '">' + row['gsx$library']['$t'] + '</a></p>';
        table += '</td>';
      } else {
        columns.forEach((column) => {
          // Add a conditional here if you want to format a particular column
          if( column == 'gsx$library' ) {
            table += '<td><a target="_blank" href="https://maps.google.com?q=' + row[column]['$t'] + '">' + row['gsx$location']['$t'] + '</a></td>';
          } else {
            table += '<td>' + row[column]['$t'] + '</td>';
          }
          //table += '<td>' + row[column]['$t'] + '</td>';
        }); 
      }
      table += '</td></tr>';
    });
    table += '</tbody>';
    table += '</table>';

    // Output the table HTML
    document.getElementById(id).innerHTML = table;
    // Convert into a data table
    $('#itemTable table').DataTable({
      lengthChange: false,
      language: {
        search: "Search " + itemPluralName.toLowerCase(),
        zeroRecords: "No " + itemPluralName.toLowerCase() + " found",
        infoFiltered: "",
      },
    });
  } catch(error) {
    console.error(error);
  }
}

displayTable('itemTable');
